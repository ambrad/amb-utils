function varargout = dmdl(fn,varargin)
% Space debris model. See
%   A.M. Bradley and L.M. Wein, "Space Debris: Assessing Risk and
%   Responsibility", Adv. in Space Research 43 (2009) 1372-1390.
%
% Typical usage:
%    load data_noFF; % Load the no-fragment-fragment model parameters. This
%                    % parameter set is almost always what you want. The
%                    % fragment-fragment set (data_FF) is used only for
%                    % understanding the impact of F-F collisions in the
%                    % model.
%    opts = dmdl('DataOpts');  % Set default options.
%    % ... change options values if desired ...
%    d = dmdl('Data',pc,opts); % Set up the model.
%    r = dmdl('Run',d,timeHorizon); % Integrate.
%    plot(r.T,[r.FRh r.FSh]); % Plot rsults. In this case, we plot the number
%                             % of hazardous fragments as a function of time.
%
% The primary output is the structure r. Most of the fields show model
% results. Some are not externally useful. The useful ones are the following:
%    T:     Time
%    Sno:   Operational (op) nondeorbiting (ndo) spacecraft (S)
%    Sn:    Nonop ndo S
%    Sd:    Op deorbiting (do) S
%    FRh:   Hazardous (H) fragments (F) from rockets (R). See the paper to
%           understand what 'hazardous' and 'benign' mean. In particular, it
%           is important to realize these are expected values. One cannot
%           actually say in advance whether a fragment is hazardous, as its
%           hazard depends on the orbital geometry  of a particular collision
%           in addition to its mass.
%    FRb:   Benign (B) F from R
%    FSh:   H F from S
%    FSb:   B F from S
%    *des:  Objects destroyed
%    Sohit: Op S hit (including those not destroyed)
%    II:    Intact-intact collisions
%    IFh:   Intact-hazardous fragment collisions
%    IFb:   Intact-benign fragment collisions
%    FFh:   Catastrophic F-F collisions
%    FFb:   Noncat F-F collisions
%    FFa:   All F-F collisions
%    oconj: Conjunctions (=collisions only if opts.opCld=1) between op S and
%           other objects.
%
% The real value of this model is the ability to test out new ideas. Feel
% free to modify the model and code however you wish.

% Version 083009 AMB.

  [varargout{1:nargout}] = feval(fn,varargin{:});
  
function c = Ptrs
% Return indices into the array of curves.
  persistent pc;
  if(isempty(pc))
    done = 1;
    % oconj is number of conjunctions between operating spacecraft and other
    % objects
    nms = {'R' 'Sno' 'Sn' 'Sd' 'Sdu' 'FRh' 'FRb' 'FSh' 'FSb' 'Rdes'...
	   'Sndes' 'Sodes' 'Sohit' 'II' 'IFh' 'IFb' 'FFh' 'FFa' 'oconj'};
    pc.nms = nms;
    for(i = 1:length(nms))
      pc.(nms{i}) = i;
    end
  end
  c = pc;
  
function opts = DataOpts
% These are some commonly altered parameters. You may end up digging into the
% next function, Data, to alter some others.
  
  % Use FengYun 1C debris
  opts.useFY = true;
  % Deorbit compliance rate
  opts.theta = 2/3;
  % Nondeorbiting rocket body insertions per year
  opts.lambda_R = 1;
  % Turn off rocket body inserts after this many years
  opts.switchLambdaR = 10;
  % Operational SC collision rate as a fraction of conjunction rate. For
  % example, if an operational spacecraft can perform collision avoidance
  % with success rate 90%, then opCld = 0.1.
  opts.opCld = 1;
  % Can an operational SC avoid fragments as well as intacts?
  opts.avdFrags = true;
  % Insert one new fragment for each newly injected spacecraft.
  opts.pstv_lambda_FSh = false;
  % Average operational lifetime
  opts.opLife = 3;
  % Number of spacecraft insertions per year
  opts.lambda_o = 3;

function d = Data(pc,opts)
  if(nargin < 2) opts = DataOpts; end
    
  fns = fieldnames(pc);
  for(i = 1:length(fns))
    fn = fns{i};
    d.(fn) = pc.(fn);
  end
    
  % Include pole factor
  d.beta = d.beta.*d.f;
  d.betaFF = d.betaFF.*d.f;
  
  % Stretch out D and beta to have a duplicate column for S. beta now has
  % indices {R Sn So FRh FRb FSh FSb}
  flds = {'beta' 'betaFF' 'D'};
  for(i = 1:3)
    A = d.(flds{i});
    A = [A(1:2,:,:); A(2,:,:); A(3:end,:,:)];
    A = [A(:,1:2,:) A(:,2,:) A(:,3:end,:)];
    % Include avoidance factor for operational spacecraft
    if(i <= 2)
      d.(['orig_' flds{i}]) = A(3,:);
      if(opts.opCld < 1)
	A(3,1:2) = A(3,1:2)*opts.opCld;
	% 2 ops collide w/ prob cld^2
	%A(3,3) = A(3,3)*opts.opCld^2;
	A(3,3) = A(3,3)*opts.opCld; % Will doesn't like the squaring.
	if(opts.avdFrags)
	  A(3,4:end) = A(3,4:end)*opts.opCld;
	end
	A(:,3) = A(3,:)';
      end
    end
    d.(flds{i}) = A;
  end

  d.mu_o = 1/opts.opLife;
  d.lambda_o = opts.lambda_o;
  d.theta = opts.theta;
  d.lambda_R = opts.lambda_R;
  d.switchLambdaR = opts.switchLambdaR;
  d.Sdu_0 = 0;
  d.avdFrags = opts.avdFrags;
  d.opCld = opts.opCld;
  if(opts.pstv_lambda_FSh) d.lambda_FSh = d.lambda_o;
  else d.lambda_FSh = 0; end
  
  switch(d.crit)
   case 'lo'
    Ft_0 = 252.43; Ffy_0 =   0.14;
    d.Sn_0 = 174.96; d.R_0 = 159.72;
   case 'mid1'
    Ft_0 = 554.62; Ffy_0 = 400.87;
    d.Sn_0 = 207.20; d.R_0 = 183.27;
   case 'mid2'
    Ft_0 = 504.00; Ffy_0 =   1.00;
    d.Sn_0 = 240.00; d.R_0 = 198.00;
   case 'hi'
    Ft_0 = 2011.00; Ffy_0 = 1374.00;
    d.Sn_0 = 430.00; d.R_0 = 648.00;
  end
  d.Sd_0 = d.theta*d.lambda_o/d.mu_o;
  d.Sno_0 = (1-d.theta)*d.lambda_o/d.mu_o;
  d.Sn_0 = d.Sn_0 - d.Sd_0 - d.Sno_0;
  
  b = 0.1;
  p = pc.d ./ repmat(sum(pc.d),2,1);
  d.FRh_0 = p(1,1)*(1-b)*Ft_0; d.FRb_0 = p(2,1)*(1-b)*Ft_0;
  d.FSh_0 = p(1,2)*b*Ft_0;     d.FSb_0 = p(2,2)*b*Ft_0;
  
  if(opts.useFY)
    d.FSh_0 = d.FSh_0 + p(1,2)*Ffy_0;
    d.FSb_0 = d.FSb_0 + p(2,2)*Ffy_0;
  end
  
function r = Run(d,dT,tight)
% Integrate the model.
%   dT is either a duration or a list of times at which to compute the
% values.
%   d is the Data struct.
%   tight is optional. If 1, increase the relative tolerance of the solver.
  if(nargin < 3) tight = 0; end
  r.d = d;
  dT1 = dT(end);
  % Switch lambda_R off after some initial time period?
  if(d.switchLambdaR < dT(end))
    dT1 = d.switchLambdaR;
  end
  % Increase relative tolerance?
  if(tight)
    opts = odeset('RelTol',1e-6);
  else
    opts = odeset;
  end
  % Determine whether we need to get values at particular time points
  if(length(dT) > 1)
    idx = find(dT <= dT1); idx = idx(end);
    T = dT(1:idx);
    if(T(end) ~= dT1) T(end+1) = dT1; end
  else
    T = [0 dT1];
  end
  % Integrate the first (or only) bit
  y0 = [d.R_0 d.Sno_0 d.Sn_0 d.Sd_0 d.Sdu_0 d.FRh_0 d.FRb_0 d.FSh_0 d.FSb_0 ...
	zeros(1,10)]; 
  [r.T r.Y] = ode23s(@(t,y)OdeFn(t,y,d),T,y0,opts);
  % Switch lambda_R off?
  if(dT1 < dT(end))
    if(length(dT) > 1)
      T = dT(idx+1:end);
      if(T(1) ~= dT1) T = [dT1; T(:)]; end
    else
      T = [dT1 dT];
    end
    % Yep, so integrate the rest
    d.lambda_R = 0;
    [T Y] = ode23s(@(t,y)OdeFn(t,y,d),T,r.Y(end,:),opts);
    r.T = [r.T; T(2:end)];
    r.Y = [r.Y; Y(2:end,:)];
  end
  % Give r a bunch of named variable fields
  c = Ptrs;
  for(i = 1:length(c.nms))
    r.(c.nms{i}) = r.Y(:,i);
  end
  % F-F benign = F-F all - F-F hazardous
  r.FFb = r.FFa - r.FFh;

function yp = OdeFn(t,y,d)
% y = [R Sno Sn Sd Sdu FRh FRb FSh FSb N Rdes Sndes Sodes Sohit
%      II IFh IFb FFh FFa oconj]
  c = Ptrs;
  y = y(:);
  yp = zeros(length(y),1);
  % Sa is indexed the same as d.beta
  Sa = [y(c.R); y(c.Sn); y(c.Sno)+y(c.Sd)+y(c.Sdu); y(c.FRh:c.FSb)];
  % mu is originally [R Sn FRh FRb FSh FSb]. Make it [R Sno Sn Sd Sdu FRh FRb
  % FSh FSb].
  mu = [d.mu(1) d.mu_o d.mu(2) d.mu_o d.mu_o d.mu(3:end)];
  % lambda
  lambda = [d.lambda_R (1-d.theta)*d.lambda_o d.mu_o*y(c.Sno) d.theta*d.lambda_o 0];
  % Indices into d.beta and Sa, which are indexed identically
  Iidxs = [1:4 6]; IIidxs = 1:3; IFhidxs = [4 6]; IFbidxs = [5 7];
  % A new set of indices for hits
  IHidxs = 1:7;
  % Indices for computing Rdes, Sndes, Sodes, and Sohit
  desIdxs = {1 3 [2 4] [2 4]};
  % Map [R Sno Sn Sd Sdu] to [R Sn So]
  mapIdxs = [1 3 2 3 3];
  for(i = 1:c.Sdu)
    if(i <= 4)
      for(j = desIdxs{i})
	if(i <= 3)
	  % Rdes, Sndes, Sodes
	  yp(c.FSb+i) = yp(c.FSb+i) + y(j)*d.beta(i,Iidxs)*Sa(Iidxs);
	else
	  % Sohit
	  yp(c.FSb+i) = yp(c.FSb+i) + y(j)*d.beta(3,IHidxs)*Sa(IHidxs);
	end
      end
    end
    k = mapIdxs(i);
    yp(i) = -y(i)*d.beta(k,Iidxs)*Sa(Iidxs) - mu(i)*y(i) + lambda(i);
    yp(c.IFh) = yp(c.IFh) + y(i)*d.beta(k,IFhidxs)*Sa(IFhidxs);
    yp(c.IFb) = yp(c.IFb) + y(i)*d.beta(k,IFbidxs)*Sa(IFbidxs);
  end
  yp(c.II) = 1/2*d.beta(1,1)*Sa(1)^2 + sum(d.beta(1,2:3)*Sa(1)*Sa(2:3)) +...
      1/2*d.beta(2,2)*Sa(2)^2 + d.beta(2,3)*Sa(2)*Sa(3) +...
      1/2*d.beta(3,3)*Sa(3)^2;
  % New field: operational conjunctions with all other objects. If OO
  % conjunct, that counts as two. orig_beta has the unmod'ed values.
  yp(c.oconj) = sum(d.orig_beta.*Sa(3).*Sa');
  for(i = c.FRh:c.FSb)
    j = i-c.FRh+1; % Index starting at 1
    A = d.D(:,:,j).*d.beta.*(Sa*Sa');
    A = diag(diag(A)/2) + triu(A,1);
    yp(i) = sum(A(:)) - mu(i)*y(i);
    if(i == c.FSh) yp(i) = yp(i) + d.lambda_FSh; end
    % Count total F-F (even benign) collisions
    if(isfield(d,'betaFF') & d.D(4,4) > 0)
      k = j+3; % Index the F entries of beta and D
      FFidxs = 4:7;
      yp(c.FFh) = yp(c.FFh) + Sa(k)*dot(d.beta(k,FFidxs),Sa(FFidxs));
      yp(c.FFa) = yp(c.FFa) + Sa(k)*dot(d.betaFF(k,FFidxs),Sa(FFidxs));
    end
  end
